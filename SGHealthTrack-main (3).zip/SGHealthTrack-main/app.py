from flask import Flask, render_template, request, redirect, url_for
from flask_login import LoginManager, UserMixin, login_user, login_required
import os

# Initialize Flask app
app = Flask(__name__,
            static_folder='static',
            template_folder='SGHealthTrack')

# Set secret key for Flask-Login
app.secret_key = os.urandom(24)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'index'

# Error handling
@app.errorhandler(401)
def unauthorized(e):
    return render_template('index.html', error='Please log in to access this page'), 401

@app.errorhandler(404)
def not_found(e):
    return render_template('index.html', error='Page not found'), 404

@app.errorhandler(500)
def internal_error(e):
    return render_template('index.html', error='Internal server error'), 500

# Mock user class (replace with real user model later)
class User(UserMixin):
    def __init__(self, id, username, role):
        self.id = id
        self.username = username
        self.role = role

# Mock user database (replace with real database later)
users = {
    'admin': User(id=1, username='admin', role='admin')
}

@login_manager.user_loader
def load_user(user_id):
    return users.get('admin')

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/signup')
def signup():
    return render_template('signup.html')

@app.route('/register', methods=['POST'])
def register():
    # Get form data
    fullname = request.form.get('fullname')
    email = request.form.get('email')
    username = request.form.get('username')
    role = request.form.get('role')
    password = request.form.get('password')
    
    # TODO: Add real database connection and user registration logic here
    # For now, we'll just redirect to dashboard
    return redirect(url_for('dashboard'))

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    
    if not username or not password:
        return render_template('index.html', error='Please enter both username and password'), 400
    
    # For now, we'll accept any username with password "Password123"
    if password == "Password123":
        user = users.get(username)
        if user:
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            return render_template('index.html', error='User not found'), 401
    else:
        return render_template('index.html', error='Invalid password'), 401

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

def setup_firewall_rule():
    """Create firewall rule for Flask app"""
    try:
        # Check if rule exists
        result = subprocess.run(['netsh', 'advfirewall', 'firewall', 'show', 'rule', 'name=Flask App Network'], 
                              capture_output=True, text=True)
        if "No rules match the specified criteria." in result.stdout:
            # Add the rule
            subprocess.run(['netsh', 'advfirewall', 'firewall', 'add', 'rule', 
                          'name=Flask App Network', 'dir=in', 'action=allow', 
                          'protocol=TCP', 'localport=8000', 'profile=domain,private'],
                         capture_output=True)
            print("\nFirewall rule created successfully")
        else:
            print("\nFirewall rule already exists")
    except Exception as e:
        print(f"\nWarning: Could not create firewall rule: {str(e)}")
        print("You may need to manually allow incoming connections on port 8000")

if __name__ == '__main__':
    # Get the IP address of your machine
    import socket
    import os
    import subprocess
    import sys
    
    # Setup firewall rule
    setup_firewall_rule()
    
    # Get the IP address
    ip_address = subprocess.check_output(['ipconfig']).decode('utf-8')
    ip_address = [line for line in ip_address.split('\n') if 'IPv4 Address' in line][0]
    ip_address = ip_address.split(':')[1].strip().replace(')', '')
    
    # Test if port 8000 is accessible
    try:
        import socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(('0.0.0.0', 8000))
        sock.close()
        print("\nPort 8000 is available")
    except socket.error as e:
        print(f"\nError: Port 8000 is not available: {str(e)}")
        print("Try using a different port number")
        sys.exit(1)
    
    # Print access information
    print("\nSG HealthTrack is running!")
    print("=====================================")
    print(f"Local: http://localhost:8000")
    print(f"Network: http://{ip_address}:8000")
    print("=====================================")
    print("Note: Make sure your firewall allows incoming connections on port 8000")
    print("Access the network URL from other devices on your network")
    
    # Run the app with proper network configuration
    app.run(
        host='0.0.0.0',  # Listen on all network interfaces
        port=8000,
        debug=True,
        threaded=True,  # Handle multiple requests
        use_reloader=False  # Disable reloader to avoid multiple instances
    )
