# SG HealthTrack - Clinic Management System

## Overview

SG HealthTrack is a web-based clinic management system designed to streamline healthcare operations. It provides user authentication, patient management, appointment scheduling, and basic analytics for healthcare professionals.

## Features

- User authentication (login/logout)
- Role-based access control (admin, doctor, nurse, receptionist, user)
- Patient queue management
- Appointment scheduling
- Payment tracking
- Real-time analytics dashboard
- Multi-device access support

## Setup Instructions

### Prerequisites

1. Python 3.7 or higher
2. Flask and required dependencies
3. Web browser

### Installation

1. Install Python from the official website (https://www.python.org/downloads/)
   - During installation, check "Add Python to PATH"

2. Install required packages:
   ```bash
   pip install flask flask-login
   ```

### Running the Application

1. Open Command Prompt as Administrator:
   - Right-click Command Prompt and select "Run as Administrator"

2. Navigate to the project directory:
   ```bash
   cd c:\xampp\htdocs\SGHealthTrack-main
   ```

3. Add firewall rule (only needed once):
   ```bash
   netsh advfirewall firewall add rule name="Flask App Network" dir=in action=allow protocol=TCP localport=8000 profile=domain,private
   ```

4. Run the Flask application:
   ```bash
   python app.py
   ```

### Accessing the Application

1. Local Access:
   - Open your web browser
   - Go to: http://localhost:8000
   - Login with demo credentials:
     Username: admin
     Password: Password123

2. Network Access (From Other Devices):
   - Find your computer's IP address:
     - Open Command Prompt
     - Type: ipconfig
     - Look for "IPv4 Address" under your network adapter
   - Other devices on the same network can access:
     http://YOUR_IP_ADDRESS:8000
   - Example: http://192.168.100.6:8000

### Troubleshooting

1. If you can't access the application:
   - Make sure Flask is running (check Command Prompt)
   - Verify your firewall settings
   - Ensure devices are on the same network
   - Try a different port number if 8000 is blocked

2. If login doesn't work:
   - Check if Flask-Login is properly installed
   - Verify session cookies are enabled in your browser
   - Clear browser cache and cookies

3. If dashboard is empty:
   - Make sure all static files are in the correct location
   - Verify CSS and JavaScript paths in HTML files
   - Check browser console for errors

## Security Notes

- This is a development version
- Default credentials should be changed in production
- Access is limited to devices on the same network
- Consider HTTPS for production deployment

## Demo Credentials

- Username: admin
- Password: Password123

Note: These credentials are for development purposes only and should be changed in production environments.
